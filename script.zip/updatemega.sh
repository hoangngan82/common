#!/bin/sh
url='http://www.megamillions.com/winning-numbers'
httpcode=503
while [ $httpcode != "200" ] ; do
  httpcode=$(wget --server-response -O /tmp/megaresult $url 2>&1 | awk '/^  HTTP/{print $2;}')
  sleep 1
done
result=$(awk '/white-ball/ || /mega-ball/ {
  getline;
  print $0
}' /tmp/megaresult | awk '{if ($1 < 10) printf("0"); 
printf("%d,", $1);}')
dateold=$(date)
datediff=1
today=$(date --date="$dateold - $datediff days" +%F)
result=$today","$result
estimatedJackpot=$(awk '/>Estimated Jackpot/ {
  for(i=0;i<6;i++) getline; print $0;
  getline;print $0}' /tmp/megaresult | sed 's/,//g' | awk -F"[<>]" '{
  if (length($3) == 9) printf(" "); printf("%s,", $3 "");
  }')
multiplier=$(awk '/numbers-megaplier/ {
    getline; print $0
  }' /tmp/megaresult | sed 's/x//g' | awk '{printf("0%d,", $2)}')
result=$result$multiplier$estimatedJackpot
echo ", , , , , , , , " > /tmp/megaresult
echo $result >> /tmp/megaresult
echo $result >> /home/hoangngan/system/scripts/megamillions.csv
/home/hoangngan/system/scripts/megamillions.sh /tmp/megaresult >> /home/hoangngan/mymega
echo $result
tail /home/hoangngan/mymega
