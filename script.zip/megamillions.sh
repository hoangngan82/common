#!/bin/sh
filename=megamillions.csv
if [ "$1" != "" ]; then
  filename=$1
fi
#num[1] = 2
#num[2] = 41
#num[3] = 42
#num[4] = 56
#num[5] = 74
#num[6] = 7
awk -F, 'BEGIN {
num[1] = 6
num[2] = 12
num[3] = 34
num[4] = 55
num[5] = 62
num[6] = 9
}
NR > 1 && $1 > "2017-01-01" {
i = 2; j = 1;
match5 = 0;
matchb = 0;
while ( i < 7 && j < 6 ) {
  if ($i == num[j]) {
    i++; j++; match5++;
  } else {
    if ($i > num[j]) 
      j++
    else
      i++;
  }
}
if ($7 == num[6]) 
  matchb++;
prize=0;
if (matchb == 0) {
  if (match5 == 3) prize = 5;
  if (match5 == 4) prize = 500;
  if (match5 == 5) prize = 1000000;
} else {
  if (match5 == 0) prize = 1;
  if (match5 == 1) prize = 2;
  if (match5 == 2) prize = 5;
  if (match5 == 3) prize = 50;
  if (match5 == 4) prize = 5000;
  if (match5 == 5) prize = 10000000;
}
if (prize == 0) print $1 ": no";
if (prize == 1000000) print $1 ": prize is $1M";
if (prize == 10000000) print $1 ": ***** JACKPOT *****";
if ( prize > 0 && prize < 1000000 ) print $1 ": prize is $" prize;
}' $filename
